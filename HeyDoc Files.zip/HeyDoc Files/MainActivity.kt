import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.FlowColumnScopeInstance.align
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Text
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.draw.clip
import androidx.compose.ui.tooling.preview.Preview
import com.example.heydoc2.R

@Composable
fun AndroidLargeSignInRegister(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .width(360.dp)
            .height(800.dp)
            .background(color = Color.White)
    ) {
        SignInRegisterContent()
        StatusBarSection()
    }
}

@Composable
fun SignInRegisterContent() {
    Box(modifier = Modifier.fillMaxSize()) {
        Image(
            painter = painterResource(id = R.drawable.heydoc11),
            contentDescription = "Hey, Doc Image",
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 60.dp)
                .size(width = 322.dp, height = 291.dp)
                .clip(RoundedCornerShape(59.dp))
        )
        SignInButton()
        SignUpButton()
        DividerText()
        GoogleSignUpButton()
    }
}

@Composable
fun SignInButton() {
    Box(
        modifier = Modifier.run {
            align(Alignment.TopCenter)
                .padding(top = 411.dp)
                .size(276.dp, 57.dp)
                .clip(RoundedCornerShape(60.dp))
                .background(color = Color.White)
                .border(2.dp, Color(0xff12229d), RoundedCornerShape(60.dp))
        }
    )
    Text(
        text = "Log in",
        color = Color.Black,
        textAlign = TextAlign.Center,
        style = TextStyle(
            fontSize = 24.sp,
            fontWeight = FontWeight.Medium,
            letterSpacing = 0.25.sp
        ),
        modifier = Modifier
            .align(Alignment.TopCenter)
            .padding(top = 425.dp)
            .width(195.dp)
            .height(29.dp)
    )
}

@Composable
fun SignUpButton() {
    Image(
        painter = painterResource(id = R.drawable.rectangle2),
        contentDescription = "Sign Up Background",
        modifier = Modifier
            .align(Alignment.TopCenter)
            .padding(top = 499.dp)
            .size(276.dp, 57.dp)
            .clip(RoundedCornerShape(60.dp))
            .border(2.dp, Color(0xff12229d), RoundedCornerShape(60.dp))
    )
    Text(
        text = "Sign up",
        color = Color.Black,
        textAlign = TextAlign.Center,
        style = TextStyle(fontSize = 24.sp, letterSpacing = 0.25.sp),
        modifier = Modifier
            .align(Alignment.TopCenter)
            .padding(top = 512.dp)
            .width(80.dp)
            .height(30.dp)
    )
}

@Composable
fun DividerText() {
    Image(
        painter = painterResource(id = R.drawable.line2),
        contentDescription = "Divider Line",
        modifier = Modifier
            .align(Alignment.TopCenter)
            .padding(top = 588.dp)
            .width(317.dp)
            .border(2.dp, Color(0xff12229d))
    )
    Text(
        text = "OR",
        color = Color.Black,
        textAlign = TextAlign.Center,
        style = TextStyle(fontSize = 15.sp, letterSpacing = 0.25.sp),
        modifier = Modifier
            .align(Alignment.TopCenter)
            .padding(top = 576.dp)
    )
}

@Composable
fun GoogleSignUpButton() {
    Image(
        painter = painterResource(id = R.drawable.google_logo),
        contentDescription = "Google Logo",
        modifier = Modifier
            .align(Alignment.TopCenter)
            .padding(top = 617.dp, start = 52.dp)
            .size(35.dp)
    )
    Text(
        text = "Sign up with Google",
        color = Color.Black,
        style = TextStyle(fontSize = 20.sp),
        modifier = Modifier
            .align(Alignment.TopCenter)
            .padding(top = 623.dp, start = 108.dp)
    )
}

@Composable
fun StatusBarSection() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(40.dp)
            .padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "9:30",
            color = Color(0xff171d1b),
            style = TextStyle(fontSize = 14.sp),
            modifier = Modifier.wrapContentHeight(Alignment.CenterVertically)
        )
        Row(
            horizontalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.wifi),
                contentDescription = "Wifi",
                colorFilter = ColorFilter.tint(Color(0xff171d1b)),
                modifier = Modifier.size(16.dp)
            )
            Image(
                painter = painterResource(id = R.drawable.signal),
                contentDescription = "Signal",
                colorFilter = ColorFilter.tint(Color(0xff171d1b)),
                modifier = Modifier.size(16.dp)
            )
            Image(
                painter = painterResource(id = R.drawable.battery),
                contentDescription = "Battery",
                colorFilter = ColorFilter.tint(Color(0xff171d1b)),
                modifier = Modifier.size(16.dp)
            )
        }
    }
}

@Preview(widthDp = 360, heightDp = 800)
@Composable
fun AndroidLargeSignInRegisterPreview() {
    AndroidLargeSignInRegister()
}
